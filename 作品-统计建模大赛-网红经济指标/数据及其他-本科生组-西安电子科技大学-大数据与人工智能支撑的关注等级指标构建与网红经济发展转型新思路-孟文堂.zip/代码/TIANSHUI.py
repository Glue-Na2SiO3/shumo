import pandas as pd
df=pd.read_excel(r"新建 XLSX 工作表.xlsx")
num=0
num1=0
for i in df["转发数"]:
    if (i=='  转发' or i==' 转发')or i=="转发数":
        df["转发数"][num]=0
    else:
        df["转发数"][num]=int(i)
    num+=1
for i in df["点赞数"]:
    if i=="赞" or i=="点赞数":
        df["点赞数"][num1]=0
    else:
        df["点赞数"][num1]=int(i)
    num1+=1
#df1=df.groupby("时间").count()
df2=df.groupby("时间").sum()
#df1.to_excel("哈尔滨宠粉汇总表1.xlsx")
df2.to_excel("哈尔滨宠粉汇总表2.xlsx")
