# coding: utf-8
import pandas as pd
import jieba
import time
import os
dir_path=r"C:\Users\ASUS\Desktop\哈尔滨文本"
dir=os.listdir(dir_path)
for i in dir:
    filepath=dir_path+"\\"+i
    print(filepath)
    # -------------------------------------获取数据集---------------------------------
    f = open(filepath, 'r',encoding='utf-8')
    test=f.read()
    # -------------------------------------情感词典读取-------------------------------
    # 注意：
    # 1.词典中怒的标记(NA)识别不出被当作空值,情感分类列中的NA都给替换成NAU
    # 2.大连理工词典中有情感分类的辅助标注(有NA),故把情感分类列改好再替换原词典中

    # 扩展前的词典
    df = pd.read_excel('情感词汇本体.xlsx')

    df = df[['词语', '词性种类', '词义数', '词义序号', '情感分类', '强度', '极性']]


    # -------------------------------------七种情绪的运用-------------------------------
    Happy = {}
    Good = {}
    Surprise = {}
    Anger = {}
    Sad = {}
    Fear = {}
    Disgust = {}

    for idx, row in df.iterrows():
        if row['情感分类'] in ['PA', 'PE']:
            Happy[row['词语']]=row['强度']
        if row['情感分类'] in ['PD', 'PH', 'PG', 'PB', 'PK']:
            Good[row['词语']]=row['强度']
        if row['情感分类'] in ['PC']:
            Surprise[row['词语']]=row['强度']
        if row['情感分类'] in ['NB', 'NJ', 'NH', 'PF']:
            Sad[row['词语']]=row['强度']
        if row['情感分类'] in ['NI', 'NC', 'NG']:
            Fear[row['词语']]=row['强度']
        if row['情感分类'] in ['NE', 'ND', 'NN', 'NK', 'NL']:
            Disgust[row['词语']]=row['强度']
        if row['情感分类'] in ['NAU']:  # 修改: 原NA算出来没结果
            Anger[row['词语']]=row['强度']

        # 正负计算不是很准 自己可以制定规则
    Positive = {}
    Negative = {}
    for i in Happy:
        Positive[i]=Happy[i]
    for i in Good:
        Positive[i]=Good[i]
    for i in Surprise:
        Positive[i]=Surprise[i]
    for i in Sad:
        Negative[i]=Sad[i]
    for i in Fear:
        Negative[i]=Fear[i]
    for i in Disgust:
        Negative[i]=Disgust[i]
    for i in Anger:
        Negative[i]=Anger[i]


    temp= pd.read_excel('stop_words.xlsx')
    stop_list = temp['停用词'].tolist()

    def txt_cut(juzi):
        return [w for w in jieba.lcut(juzi) if w not in stop_list]

    wordlist=txt_cut(test)

    def emotion_caculate(text):
        positive = 0
        negative = 0

        for word in wordlist:
            if word in Positive:
                positive += Positive[word]
            if word in Negative:
                negative += Negative[word]
        result=positive/(positive+negative)
        return result
    result=emotion_caculate(test)
    print(result)

