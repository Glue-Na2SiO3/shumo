import gensim.corpora as corpora
import pandas as pd
from jieba import analyse
import jieba
from gensim import models
import re
from sklearn.feature_extraction.text import  CountVectorizer,TfidfVectorizer
from sklearn.decomposition import LatentDirichletAllocation
import numpy as np
from imageio import imread #调用蒙版相关函数
import wordcloud
import os
#
# def txt_cut(juzi):
#     return [w for w in jieba.lcut(juzi) if w not in stop_list]
#
# def max_index(list,len):
#     max=list[0]
#     index=0
#     for i in range(len):
#         if max<list[i]:
#             max=list[i]
#             index=i
#     return index
#
# def print_top_words(model, feature_names, n_top_words):
#     theme_word=[]
#     theme_word_score=[]
#     result=[]
#     tword = []
#     tword2 = []
#     tword3=[]
#     topic_w=[]
#     topic_pro =[]
#     place=max_index(topics[0],10)
#     for topic_idx, topic in enumerate(model.components_):
#         if topic_idx==place:
#             topic_w = [feature_names[i] for i in topic.argsort()[:-n_top_words - 1:-1]]
#             topic_pro=[str(round(topic[i],3)) for i in topic.argsort()[:-n_top_words - 1:-1]]  #(round(topic[i],3))
#             #tword.append(topic_w)
#             #tword2.append(topic_pro)
#             #print(" ".join(topic_w))
#             #print(" ".join(topic_pro))
#             #print(' ')
#             #word_pro=dict(zip(topic_w,topic_pro))
#             #tword3.append(word_pro)
#             #theme_word.append(topic_w[place])
#             #theme_word_score.append(topic_pro[place])
#             #result.append([theme_word[-1],theme_word_score[-1]])
#     for i in range(n_top_words):
#         result.append([topic_w[i],topic_pro[i]])
#     return result
#
temp = pd.read_excel('stop_words.xls')
stop_list = temp['停用词'].tolist()
#
# dir_path=r"D:\STUDY\统计建模2024\淄博主题分析文本"
# dir=os.listdir(dir_path)
# for i in dir:
#     filepath=dir_path+"\\"+i
#     print(filepath)
#     filepath=r"D:\STUDY\统计建模2024\淄博主题分析文本\5.1到5.15.txt"
#     print(filepath)
#     # -------------------------------------获取数据集---------------------------------
#     f = open(filepath, 'r',encoding='utf-8')
#     test=f.read()
#     f = open(filepath, 'r',encoding='utf-8')
#     test=f.read()
#     wordlist = txt_cut(test)
#
#     wordlist=[i for i in wordlist if re.match(r"[\u4e00-\u9fa5]", i)] #保留汉字
#
#     tf_vectorizer = TfidfVectorizer()
#     #tf_vectorizer = TfidfVectorizer(ngram_range=(2,2)) #2元词袋
#     X = tf_vectorizer.fit_transform(wordlist)
#     #print(tf_vectorizer.get_feature_names_out())
#
#     n_topics = 10  #分为10类
#     lda = LatentDirichletAllocation(n_components=n_topics, max_iter=100,
#                                     learning_method='batch',
#                                     learning_offset=100,
#     #                                 doc_topic_prior=0.1,
#     #                                 topic_word_prior=0.01,
#                                    random_state=0)
#     lda.fit(X)
#
#     #输出每篇文章对应主题
#     topics=lda.transform(X)
#     topic=np.argmax(topics,axis=1)
#     #df.to_excel("data_topic.xlsx",index=False)
#     print(topics.shape)
#     print(topics[0])
#
#
#
#     ##输出每个主题对应词语和概率
#     n_top_words = 20
#     feature_names = tf_vectorizer.get_feature_names_out()
#     word_pro = print_top_words(lda, feature_names, n_top_words)
#     print(word_pro)




#print(jieba.analyse.extract_tags(test,topK=20,withWeight=True,allowPOS=()))

# id2word = corpora.Dictionary([wordlist])     # 创建词典
# #id2word.filter_extremes(no_below=3, no_above=0.5, keep_n=3000) # 出现次数至少为3，至少在一半文档中出现，词典大小最多3000个词（筛选）
# id2word.save_as_text("dictionary")                   # 保存词典
# corpus = [id2word.doc2bow(text) for text in [wordlist]]   # 分别对每篇文章建立词袋向量
# print(corpus)
# print([[(id2word[id], freq) for id, freq in cp] for cp in corpus])
#
# tfidf_model = models.TfidfModel(corpus)
# print(tfidf_model)
# print(tfidf_model[corpus[0]])
# corpus_tfidf = [tfidf_model[doc] for doc in corpus]
# print(corpus_tfidf)
# print([[(id2word[id], freq) for id, freq in cp] for cp in corpus_tfidf])


#词云绘制
f = open('4.24.txt', 'r',encoding='utf-8')
test=f.read()
leading_word=[w for w in jieba.lcut(test) if w not in stop_list]
leading_word=" ".join(leading_word) #各个列表元素间加入一个空格符号，为加载词云文本准备,注意此时join将列表类型改为字符串类型
aaa=leading_word#.replace('张泽禹 C','张泽禹') #利用字符串类型的replace纠正错误字符，注意replace不改变字符本身，需要另外赋值
mb=imread(r'C:\Users\Vermouth\Desktop\mengban.jpg') #读取蒙版模板
w = wordcloud.WordCloud(width=1000, height=800, background_color="white", max_words=100,min_font_size=1,max_font_size=1000, #min_front_size 与 max_front_size 分别用于设置最大与最小字体
                        font_path=r"C:\Windows\Fonts\msyhbd.ttc")  #mask=mb #font_path按照上述路径查找字体种类，通过查看字体属性获取ttf文件名   colormap用于设置配色  mask用于设置蒙版
w.generate(aaa) #加载文本
w.to_file(r'C:\Users\Vermouth\Desktop\example.png')
#